//
//  TestModule.h
//  xinping-TXVideoPlugin
//
//  Created by XHY on 2020/4/22.
//  Copyright © 2020 DCloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WeexSDK.h"

NS_ASSUME_NONNULL_BEGIN

@interface TXVideoPluginModule : NSObject <WXModuleProtocol>

@end

NS_ASSUME_NONNULL_END
