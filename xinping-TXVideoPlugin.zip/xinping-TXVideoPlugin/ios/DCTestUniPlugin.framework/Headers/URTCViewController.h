//
//  URTCViewController.h
//  UnicomTRTCNPOC
//
//  Created by 陈新平 on 2020/11/30.
//

#import <UIKit/UIKit.h>
#import <TXLiteAVSDK_TRTC/TXLiteAVSDK.h>
#import "GenerateTestUserSig.h"
NS_ASSUME_NONNULL_BEGIN

@interface URTCViewController : UIViewController <TRTCCloudDelegate>
@property UInt32 sdkAppId;
@property NSString *userId;
@property UInt32 roomId;
@end

NS_ASSUME_NONNULL_END
